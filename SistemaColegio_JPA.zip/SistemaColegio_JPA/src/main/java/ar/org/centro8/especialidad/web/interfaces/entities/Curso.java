package ar.org.centro8.especialidad.web.interfaces.entities;

import ar.org.centro8.especialidad.web.interfaces.enums.Dia;
import ar.org.centro8.especialidad.web.interfaces.enums.Turno;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

@Entity
@Table(name="cursos")
public class Curso {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(unique = true, nullable = false)
    private Integer id;
    private String titulo;
    private String profesor;
    @Enumerated(value = EnumType.STRING)
    private Dia dia;
	@Enumerated(value = EnumType.STRING)
	private Turno turno;
	private String activo;

	@Transient
   	private Long cantidadAlumnos;
	/*
 	* @Transient indica que el campo alumnosCount no se mapeará a ninguna columna
	 en la base de datos. Esto es útil cuando necesito un campo en tu entidad para 
	 realizar cálculos o para pasar datos a la vista, pero no quiero que este campo 
	 se almacene en la base de datos
 	*/
	
	//inicializo el campo activo en el constructor de la entidad para que tenga un valor predeterminado.
	public Curso() {
		this.activo = "s";
	}
	
	public Curso(String titulo, String profesor, Dia dia, Turno turno, String activo) {
		this.titulo = titulo;
		this.profesor = profesor;
		this.dia = dia;
		this.turno = turno;
		this.activo = "s";
	}

	public Curso(Integer id, String titulo, String profesor, Dia dia, Turno turno, String activo) {
		this.id = id;
		this.titulo = titulo;
		this.profesor = profesor;
		this.dia = dia;
		this.turno = turno;
		this.activo = "s";
	}

	@Override
	public String toString() {
		return "Curso [id=" + id + ", titulo=" + titulo + ", profesor=" + profesor + ", dia=" + dia + ", turno=" + turno
				+ ", activo=" + activo + "]";
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getProfesor() {
		return profesor;
	}

	public void setProfesor(String profesor) {
		this.profesor = profesor;
	}

	public Dia getDia() {
		return dia;
	}

	public void setDia(Dia dia) {
		this.dia = dia;
	}

	public Turno getTurno() {
		return turno;
	}

	public void setTurno(Turno turno) {
		this.turno = turno;
	}

	public String getActivo() {
		return activo;
	}

	public void setActivo(String activo) {
		this.activo = activo;
	}

	public Long getCantidadAlumnos() {
		return cantidadAlumnos;
	}

	public void setCantidadAlumnos(Long cantidadAlumnos) {
		this.cantidadAlumnos = cantidadAlumnos;
	}


}
