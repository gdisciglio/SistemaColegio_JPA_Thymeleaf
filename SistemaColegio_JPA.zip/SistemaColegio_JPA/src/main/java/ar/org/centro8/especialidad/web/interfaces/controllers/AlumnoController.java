package ar.org.centro8.especialidad.web.interfaces.controllers;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.especialidad.web.interfaces.entities.Alumno;
import ar.org.centro8.especialidad.web.interfaces.entities.Curso;
import ar.org.centro8.especialidad.web.interfaces.repositories.AlumnoRepository;
import ar.org.centro8.especialidad.web.interfaces.repositories.CursoRepository;

@Controller
/*@RequestMapping es una anotación de Spring que se utiliza para mapear solicitudes
 HTTP a métodos de controlador. Esta anotación puede aceptar una variedad de 
 parámetros, incluyendo el método HTTP (GET, POST, etc.). */
//@RequestMapping("/alumnos")
public class AlumnoController {

    private String mensajeAlumno="Ingrese un nuevo Alumno";

    @Autowired
    private CursoRepository Cr;

    @Autowired
    private AlumnoRepository Ar;

    //Pagina Alumnos
    @GetMapping("/alumnos")
    public String getAlumno(
            @RequestParam(name="buscar", defaultValue = "", required = false) String buscar,
            @RequestParam(name = "cursoId", required = false) Integer cursoId,
            Model model){
        //Alumno alumno=new Alumno();
        model.addAttribute("mensajeAlumno", mensajeAlumno);
        model.addAttribute("alumno", new Alumno());
        //model.addAttribute("listaAlumnos", ((List<Alumno>)Ar.findByCursoId(cursoId))// Obtengo la lista de alumnos
        model.addAttribute("listaAlumnos", ((List<Alumno>)Ar.findActiveAlumnos())// Obtengo la lista de alumnos Activos
                  .stream()
                  .filter(alumnos->alumnos.getNombre()
                                          .toLowerCase()
                                          .contains(buscar.toLowerCase())
                                   || 
                                   alumnos.getApellido()
                                          .toLowerCase()
                                          .contains(buscar.toLowerCase()))
                  .collect(Collectors.toList()));
        model.addAttribute("curso", new Curso());
        model.addAttribute("listaCursos", Cr.findAllActive());
        
        return "alumnos";
    }

    //Guardar Alumno
    @PostMapping("/saveAlumno")
    public String save(
            @RequestParam(name = "curso", defaultValue = "", required = false) String curso,
            @ModelAttribute Alumno alumno){
    //busco primero el Curso por su ID y
    //luego asigno al Alumno antes de guardar el Alumno.
        Curso cursoEntidad = Cr.findById(Integer.parseInt(curso)).orElseThrow();
        alumno.setCurso(cursoEntidad);
    
        Ar.save(alumno);
        if(alumno.getId() != null){
            mensajeAlumno="Se guardó Alumno ID nº:"+alumno.getId()+" -> "
                                             +alumno.getNombre()
                                             +" "+alumno.getApellido();
        }else{
            mensajeAlumno="No se pudo guardar Alumno";
        }
        return "redirect:alumnos";
    }

}
