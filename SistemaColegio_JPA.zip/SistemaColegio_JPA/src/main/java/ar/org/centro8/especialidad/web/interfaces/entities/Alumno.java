package ar.org.centro8.especialidad.web.interfaces.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="alumnos")
public class Alumno {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(unique = true, nullable = false)
    private Integer id;
    private String nombre;
    private String apellido;
    private Integer edad;
	//private Integer id_curso;
    private String activo;

    @ManyToOne
    @JoinColumn(name = "id_curso")
    private Curso curso;
    /* El campo curso representa la relación con la entidad Curso.
       La anotación @ManyToOne indica que cada Alumno está asociado con un Curso. 
       La anotación @JoinColumn especifica que la columna id_curso en la tabla alumnos
       se usa para almacenar el ID del Curso asociado con cada Alumno. 
    */
    /*
       @Column(name = "idCurso", nullable = false)
       private Integer idCurso;
       Esta campo referencia a id_curso, no a idCurso, no hace caso a la notation @Column que es un estandar den JPA
       los campos con camel case no funcionan!!!!!!, modifique el script de la BD.
    */

    //inicializo el campo activo en el constructor de la entidad para que tenga un valor predeterminado.
    // Aquí te muestro cómo hacerlo para la entidad Curso:
    public Alumno() {
        this.activo = "s";
    }

    public Alumno(String nombre, String apellido, Integer edad, Curso curso, String activo) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.curso = curso;
        this.activo = "s";
    }

    public Alumno(Integer id, String nombre, String apellido, Integer edad, Curso curso, String activo) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.curso = curso;
        this.activo = "s";
    }

    @Override
    public String toString() {
        return "Alumno [id=" + id + ", nombre=" + nombre + ", apellido=" + apellido + ", edad=" + edad + ", activo="
                + activo + ", curso=" + curso + "]";
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public Integer getEdad() {
        return edad;
    }

    public void setEdad(Integer edad) {
        this.edad = edad;
    }

    public String getActivo() {
        return activo;
    }

    public void setActivo(String activo) {
        this.activo = activo;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    
}
