package ar.org.centro8.especialidad.web.interfaces.controllers;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.especialidad.web.interfaces.entities.Alumno;
import ar.org.centro8.especialidad.web.interfaces.entities.Curso;
import ar.org.centro8.especialidad.web.interfaces.repositories.AlumnoRepository;
import ar.org.centro8.especialidad.web.interfaces.repositories.CursoRepository;

@Controller
public class CursoController {

    private String mensajeCurso="Ingrese un nuevo Curso";

    @Autowired
    private CursoRepository Cr;

    @Autowired
    private AlumnoRepository Ar;

    //Ir a Pagina Inicio
    @GetMapping("/index")
    public String getIndex(Model model) {
        return "index";
    }

    //Pagina Cursos
    @GetMapping("/cursos")
    public String getCurso(
            @RequestParam(name = "buscar", defaultValue = "", required = false) String buscar,
            Model model) {
        //Curso curso=new Curso();
        model.addAttribute("mensajeCurso", mensajeCurso);
        model.addAttribute("curso", new Curso());
        List<Curso> cursos = ((List<Curso>) Cr.findAllActive())// Obtengo la lista de cursos
                .stream()
                .filter(curso -> curso.getTitulo()
                                      .toLowerCase()
                                      .contains(buscar.toLowerCase()))
                .collect(Collectors.toList());
        for (Curso curso : cursos) {                              //Itero sobre la lista de cursos y para cada curso, 
            long cantidadAlumnos = Ar.countByCursoId(curso.getId());//obtener el recuento de alumnos utilizando el método countByCursoId().
            curso.setCantidadAlumnos(cantidadAlumnos);
        }
        model.addAttribute("listaCursos", cursos);
        return "cursos";
    }

    //Guardar Curso
    @PostMapping("/saveCurso")
    public String save(@ModelAttribute Curso curso){
        Cr.save(curso);
        if(curso.getId() != null){
            mensajeCurso="Se guardó Curso ID nº:"+curso.getId()+" -> "+curso.getTitulo();
        }else{
            mensajeCurso="No se pudo guardar Curso";
        }
        return "redirect:cursos";
    }

    //Elimina los registros de cursos de la BD(no se recomienda)
   /*@GetMapping ("/removeCurso/{id}")
    public String removeCurso(@PathVariable (name = "id") Integer id){
        Cr.deleteById(id);
         return "redirect:/cursos";
    }*/
    //Cambio el estado de cursos y alumnos incriptos en ese curso de activo='s' -> activo='n'
    @GetMapping ("/removeCurso/{id}")
    public String removeCurso(@PathVariable (name = "id") Integer id){
        Curso curso = Cr.findById(id).orElseThrow();
        curso.setActivo("n");
        Cr.save(curso);

        //obtengo todos los alumnos que estan anotados en el curso
        List<Alumno> alumnos = Ar.findByCursoId(id);

        //cambio el estado de estos alumnos a "No activo", activo='n'
        for(Alumno alumno : alumnos){
            alumno.setActivo("n");
            Ar.save(alumno);
        }

        return "redirect:/cursos";
    }
    
}
