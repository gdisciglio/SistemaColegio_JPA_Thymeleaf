package ar.org.centro8.especialidad.web.interfaces.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ar.org.centro8.especialidad.web.interfaces.entities.Curso;

@Repository
public interface CursoRepository extends CrudRepository<Curso, Integer> {
   @Query("SELECT c FROM Curso c WHERE c.activo = 's'")
   List<Curso> findAllActive();
   //el método findAllActive usa una consulta JPQL (Java Persistence Query Language)
   //para seleccionar todos los cursos donde activo es igual a 's'.
}

/*
 -JPQL (Java Persistence Query Language)es una forma de crear consultas a entidades para almacenar en una 
 base de datos relacional. Se desarrolla basándose en la sintaxis SQL, pero no afecta directamente a la base de datos. 
 Puede recuperar datos utilizando la cláusula SELECT, puede hacer actualizaciones en lote usando las 
 cláusulas UPDATE y DELETE 3. 
 -La sintaxis de JPQL es muy similar a la de SQL y este es un lenguaje de consulta estructurado simple y 
 ampliamente utilizado, el hecho de que JPQL tenga una sintaxis similar es una ventaja. 
 -SQL trabaja directamente con tablas, registros y campos de una base de datos relacional, mientras que 
 JPQL trabaja con clases e instancias de Java.
 -Una consulta JPQL puede recuperar un objeto de entidad en lugar de un conjunto de resultados de campo de la
 base de datos, como en SQL
 -JPA introduce el concepto de JPQL, que es una forma de consulta de objetos similar a SQL, pero que opera 
 en objetos Java, no en tablas de bases de datos directamente. Esto es valioso porque permite la creación 
 de consultas de una manera más orientada a objetos y evita la escritura de SQL directo, lo que hace que el 
 código sea más portátil y legible
 */