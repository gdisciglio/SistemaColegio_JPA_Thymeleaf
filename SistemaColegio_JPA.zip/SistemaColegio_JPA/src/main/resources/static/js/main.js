/*function confirmarEliminacionCurso(id) {
    let contador = document.getElementById('contadorAlumno'+id).innerText;
    if (contador != '0') {
        alert("No se puede Borrar cursos con alumnos");
        return false;
    }
    return window.confirm("¿Estás seguro de Eliminar este Curso?")
}*/

  function confirmarEliminacionCurso() {
    return window.confirm("¿Estás seguro de Eliminar este Curso?")
}